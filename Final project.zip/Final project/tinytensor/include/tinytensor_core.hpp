
#ifndef TINYTENSOR_TINYTENSOR_HPP
#define TINYTENSOR_TINYTENSOR_HPP

//for all the includes
#include "tensor.hpp"
#include "dataloader.hpp"
#include "network.hpp"

#endif //TINYTENSOR_TINYTENSOR_HPP
