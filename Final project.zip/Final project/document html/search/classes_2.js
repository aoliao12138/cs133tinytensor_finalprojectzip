var searchData=
[
  ['maxpool2d',['MaxPool2d',['../classMaxPool2d.html',1,'']]],
  ['mnistdata',['MNISTData',['../classMNISTData.html',1,'']]]
];
