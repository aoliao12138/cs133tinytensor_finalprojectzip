var searchData=
[
  ['_7emnistdata',['~MNISTData',['../classMNISTData.html#acd3b3d5fc5b9ea3355d802aced7028fa',1,'MNISTData']]],
  ['_7enetwork',['~Network',['../classNetwork.html#a7a4e19cdb4bf0c7ecf82baa643831492',1,'Network']]]
];
