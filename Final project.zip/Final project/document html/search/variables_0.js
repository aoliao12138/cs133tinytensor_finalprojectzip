var searchData=
[
  ['_5fkernel',['_kernel',['../classTensor.html#a16dc268c722d28b8eacc595996dd9b14',1,'Tensor']]]
];
