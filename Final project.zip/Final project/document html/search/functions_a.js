var searchData=
[
  ['tanh',['Tanh',['../classTanh.html#a3eb6fd350c923b4ceef0b6dbe3f690d8',1,'Tanh']]],
  ['tensor',['Tensor',['../classTensor.html#a103cfe7ad32b3be3b62233a03e91bb59',1,'Tensor::Tensor(int x=1, int y=1, int z=1)'],['../classTensor.html#aceda8c608659edfa95c30e156700b3f1',1,'Tensor::Tensor(int x, int y, int z, double num)']]]
];
