var searchData=
[
  ['get_5fnx',['get_nx',['../classTensor.html#abbdc262dbacdab592702148051adccd6',1,'Tensor']]],
  ['get_5fny',['get_ny',['../classTensor.html#a048bfa2ded750c3d5fa64da06ea67970',1,'Tensor']]],
  ['get_5fnz',['get_nz',['../classTensor.html#a8cb08c77c5aa046a494ad3d9b1e39133',1,'Tensor']]],
  ['getname',['getName',['../classLayer.html#abd221294bb7c6794fcac221607efa92a',1,'Layer']]],
  ['getsize',['getSize',['../classMNISTData.html#a56e194e3291c40cca9d13b2f95e98a73',1,'MNISTData']]]
];
