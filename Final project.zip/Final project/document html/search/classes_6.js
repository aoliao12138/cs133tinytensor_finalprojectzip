var searchData=
[
  ['sigmoid',['Sigmoid',['../classSigmoid.html',1,'']]],
  ['softmax',['Softmax',['../classSoftmax.html',1,'']]]
];
