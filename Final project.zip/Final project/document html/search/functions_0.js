var searchData=
[
  ['add_5flayer',['add_layer',['../classNetwork.html#a26c8c8b99661eea58a2f9602906340f0',1,'Network']]]
];
