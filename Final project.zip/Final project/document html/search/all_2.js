var searchData=
[
  ['calculate',['calculate',['../classLayer.html#a93db894abc31f7b5483d035ffbd57db0',1,'Layer::calculate()'],['../classConv.html#a2124d62c3ab7fba319e7a0a1c759b8fc',1,'Conv::calculate()'],['../classMaxPool2d.html#a35d27c0096a56c8cc8fe5d327f55863a',1,'MaxPool2d::calculate()'],['../classLinear.html#a9cbb0842f699ab81f81fb9c3a62cefc3',1,'Linear::calculate()'],['../classRelu.html#aa78ddec1966f20e4b1f9611baae5eefc',1,'Relu::calculate()'],['../classSigmoid.html#aeccf284e115bc73a3c74040fd01acdb2',1,'Sigmoid::calculate()'],['../classTanh.html#a21f3da119dc4bba9cc324fd09990f535',1,'Tanh::calculate()'],['../classSoftmax.html#ac4e743bbc490e45496f574dd3534a468',1,'Softmax::calculate()']]],
  ['configure',['Configure',['../classConfigure.html',1,'']]],
  ['conv',['Conv',['../classConv.html',1,'Conv'],['../classConv.html#a15d9f581eef79ef0c9710709ae5b75c3',1,'Conv::Conv()']]],
  ['convconfigure',['ConvConfigure',['../classConvConfigure.html',1,'ConvConfigure'],['../classConvConfigure.html#a81424987eec3b1f1292cc126e4bdbe96',1,'ConvConfigure::ConvConfigure()']]],
  ['creator',['creator',['../classLayer.html#a43d8c52b1adbf847e306248d2accedf1',1,'Layer']]]
];
