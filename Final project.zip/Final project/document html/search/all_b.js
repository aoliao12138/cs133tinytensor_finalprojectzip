var searchData=
[
  ['set_5fkernel',['set_kernel',['../classTensor.html#a7d7f2ee63987997a99b416d9daff81bb',1,'Tensor']]],
  ['setkernel',['setkernel',['../classConv.html#acf444addf6b70ea8eff6e7b91c53628f',1,'Conv::setkernel()'],['../classLinear.html#a2c32d82b3507d8c27db951e097a50416',1,'Linear::setkernel()']]],
  ['setname',['setName',['../classLayer.html#a794fe98edf3d509d69dc42a160ee291f',1,'Layer']]],
  ['show',['show',['../classMNISTData.html#aa904b253865d8b75b84ed65694fad0da',1,'MNISTData']]],
  ['sigmoid',['Sigmoid',['../classSigmoid.html',1,'Sigmoid'],['../classSigmoid.html#af871f2160541f3aa75558900cae467ba',1,'Sigmoid::Sigmoid()']]],
  ['softmax',['Softmax',['../classSoftmax.html',1,'Softmax'],['../classSoftmax.html#a884f7236004c14ed1b057b8e84f10861',1,'Softmax::Softmax()']]]
];
