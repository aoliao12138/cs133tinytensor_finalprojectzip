var searchData=
[
  ['max_5ftensor_5findex',['max_tensor_index',['../classTensor.html#a529f186fc716793ef22d9361829a1cdc',1,'Tensor']]],
  ['maxpool2d',['MaxPool2d',['../classMaxPool2d.html',1,'MaxPool2d'],['../classMaxPool2d.html#ac2d6e1a103079b9bebc9b58420fa1549',1,'MaxPool2d::MaxPool2d()']]],
  ['mnistdata',['MNISTData',['../classMNISTData.html',1,'MNISTData'],['../classMNISTData.html#a4ff4019ad169378848f7dea4668239b5',1,'MNISTData::MNISTData()']]]
];
