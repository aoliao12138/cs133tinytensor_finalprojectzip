var searchData=
[
  ['operator_5b_5d',['operator[]',['../classMNISTData.html#a7c427c48461fff117180ff3f6c89ce64',1,'MNISTData']]]
];
