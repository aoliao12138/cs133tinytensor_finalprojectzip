var searchData=
[
  ['tanh',['Tanh',['../classTanh.html',1,'']]],
  ['tensor',['Tensor',['../classTensor.html',1,'']]]
];
