# Tinytensor 2.0 in dev
CS133 final project: C++ implement of a neural network

Try to implement the back propagation. It can not work well now. If you are interested, you can follow our github to see our further development. <https://github.com/aoliao12138/tinytensor/tree/backprop>

