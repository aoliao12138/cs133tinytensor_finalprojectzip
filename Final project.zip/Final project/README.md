# tinytensor

1. how to build:

```
mkdir build && cd build
cmake ..
make
```

2. to run the test for the MNIST test images:

```
./test_mnist
```

3. to make your own input image:

open the ```index.html``` in ```handwriting/```, after finish your writing, click the finish button, and then move the download ```data.txt``` into the ```tinytensor``` folder

4. to run the test for your own input image:

```
./live_demo
```

the accuracy is not as high as that on the MNIST dataset, since our generated data is slightly different from the MNIST data on the number's structure

dependencies:

- we use PyTorch to train our pretrained model

- to load the MNIST data into our program, we refer to this [repository](https://github.com/pauldpong/mnist-dataloader)
- to enable our own input, we refer to this [repository](https://github.com/Perrywzp/handwriting) to build a handwriting pad
- to measure the efficiency, we use Prof. Kneip's LapTimer tool

